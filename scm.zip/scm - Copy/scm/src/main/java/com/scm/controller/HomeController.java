package com.scm.controller;

import com.scm.Entity.User;
import com.scm.helper.MessageType;
import com.scm.services.RentService;
import com.scm.services.Userservice;
import com.scm.helper.Message;

import com.scm.userform.Userform;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

@Autowired
private Userservice userservice;
@Autowired
private RentService rentService;
      @GetMapping("/")
    public String index(){
        return "redirect:/home";
    }
    @RequestMapping("/home")
    public String home(Model m) {
        m.addAttribute("title", "home-SCM");
        return "home";
    }
    @RequestMapping("/user/rent")
    public String rent(Model model) {

        model.addAttribute("title", "Rent");
        model.addAttribute("rents", rentService.getAllRents());
        return "rent";
    }

    @RequestMapping("/about")
    public String about(Model m) {
        m.addAttribute("title", "about-SCM");
        return "about";
    }

    @RequestMapping("/contact")
    public String contact(Model m) {
        m.addAttribute("title", "contact-SCM");
        return "contact";
    }

    @RequestMapping("/services")
    public String services(Model m) {
        m.addAttribute("title", "services-SCM");
        return "services";
    }

    @RequestMapping("/login")
    public String login(Model m) {
        m.addAttribute("title", "login-SCM");
        return "login";
    }

    @RequestMapping("/register")
    public String register(Model m) {
        Userform userform = new Userform();
        //sending data from backend
        m.addAttribute("title", "register-SCM");
        m.addAttribute("userform", userform);
        userform.setName("Raja");
        userform.setEmail("Raja@gmail.com");
        userform.setPassword("123");
        userform.setAbout("Ram Ram");
        userform.setPhno("8521510556");
        
        return "register";
    }
//@ModelAttribute Userform userform used for recievs data from form;
//@Valid, BindingResult rBindingResult used for error message in validation
    @PostMapping("/do-register")
    public String doRegister(@Valid @ModelAttribute Userform userform, BindingResult rBindingResult, HttpSession session) {
        System.out.println(userform);

        if (rBindingResult.hasErrors()) {
            return "register";
        }



//        User user = User.builder()
//                .name(userform.getName())
//                .email(userform.getEmail())
//                .password(userform.getPassword())
//                .about(userform.getAbout())
//                .profilepic(userform.getPhno())
//                .profilepic("njdhjd")
//                .build();
        User user =new User();
        user.setName(userform.getName());
        user.setEmail(userform.getEmail());
        user.setPassword(userform.getPassword());
        user.setAbout(userform.getAbout());
        user.setPhoneNum(userform.getPhno());
        user.setProfilepic("acs");

        try {
            userservice.saveUser(user);
            System.out.println(user);
            // Successful registration
            Message message = Message.builder()
                    .content("Registration successful!")
                    .type(MessageType.green)  // You can set different types based on conditions
                    .build();
            session.setAttribute("message", message);
        } catch (Exception e) {
            // Error handling
            Message message = Message.builder()
                    .content("Registration failed! Please try again.")
                    .type(MessageType.red)
                    .build();
            session.setAttribute("message", message);
        }

        return "register";
    }
}
