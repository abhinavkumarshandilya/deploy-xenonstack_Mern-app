package com.scm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scm.Entity.Rent;
import com.scm.repository.reRepository;

@Service
public class RentService {
    @Autowired
    private reRepository repository;

    public List<Rent> getAllRents() {
        return repository.findAll();
    }
}