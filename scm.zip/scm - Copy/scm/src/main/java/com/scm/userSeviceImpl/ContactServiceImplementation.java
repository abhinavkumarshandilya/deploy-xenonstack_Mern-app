package com.scm.userSeviceImpl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scm.Entity.contact;
import com.scm.exception.ResourceNotFoundException;
import com.scm.repository.ContactRepository;
import com.scm.services.ContactService;
@Service
public class ContactServiceImplementation implements ContactService {
    @Autowired
    private ContactRepository contactRepository;

    @Override
    public contact save(contact contact1) {
       String contactId=UUID.randomUUID().toString();
       contact1.setId(contactId);
       return contactRepository.save(contact1);
    }

    @Override
    public contact update(contact contact1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public List<contact> getAll() {
        return contactRepository.findAll();
    }

    @Override
    public contact getById(String id) {
      return contactRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("contact not found" + id));
    }

    @Override
    public void delete(String id) {
      var cont=contactRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("contact not found" + id));
        contactRepository.delete(cont);
    }

    @Override
    public List<contact> serch(String name, String email, String phoneNumber) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'serch'");
    }

    @Override
    public List<contact> getByUserId(String userId) {
        return contactRepository.findByUserId(userId);
    }

}
