package com.scm.Entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.*;
import lombok.*;

@Entity(name = "user")
@Table(name = "users")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class User implements UserDetails {
    
    @Id
    private String userId;

    @Column(name = "userName")
    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    // You can exclude getter for specific fields using AccessLevel.NONE
    @Getter(value = AccessLevel.NONE)
    private String password;

    @Column(length = 1000)
    private String about;

    private String profilepic;

    private String phoneNum;

    // You can exclude getter for specific fields using AccessLevel.NONE
    @Getter(value = AccessLevel.NONE)
    private boolean enabled = true;

    private boolean phoneVerified = false;
    private boolean emailVerified = false;

    // Self, Google, Facebook, Twitter, Github
    @Enumerated(value = EnumType.STRING)
    private providers provider = providers.SELF;
    
    private String providerUserId;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<contact> contacts = new ArrayList<>();

  

    // You will need a field for storing roles or authorities
    @ElementCollection(fetch = FetchType.EAGER)
    // @CollectionTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"))
    // @Column(name = "role")
    private List<String> roles = new ArrayList<>();

    // Implementing methods from UserDetails interface
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.roles.stream()
                .map(role -> new SimpleGrantedAuthority(role))
                .collect(Collectors.toList());
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;  // Modify this based on your logic
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;  // Modify this based on your logic
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;  // Modify this based on your logic
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
    @Override
    public String getPassword() {
        return this.password;
    }
}
