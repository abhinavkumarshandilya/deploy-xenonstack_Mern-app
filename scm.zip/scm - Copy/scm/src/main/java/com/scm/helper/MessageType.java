package com.scm.helper;

public enum MessageType {
    red,blue,green,yellow

}
