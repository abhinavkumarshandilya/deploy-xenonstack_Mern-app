package com.scm.Entity;

public enum providers {
   SELF,GOOGLE,GITHUB
}
