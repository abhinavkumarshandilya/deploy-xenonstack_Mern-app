package com.scm.services;

import com.scm.Entity.contact;
import java.util.List;

public interface ContactService {
    contact save(contact contact1);
    contact update(contact contact1);
    List<contact>getAll();
    contact getById(String id);
    void delete(String id);
    List<contact>serch(String name,String email,String phoneNumber);
    List<contact>getByUserId(String userId);


}
