console.log("Ram Ram");
document.querySelector("input[name='contact-picture']")
.addEventListener("change", function(event) {
    let file = event.target.files[0]; // Corrected from 'file[0]' to 'files[0]'
    if (file) {
        let reader = new FileReader();
        reader.onload = function(event) {
            document
            .querySelector("#upload_image_preview")
            .setAttribute("src", event.target.result); // Use event.target.result for the image source
        };
        reader.readAsDataURL(file); // Corrected from readAsDataUrl to readAsDataURL
    }
});
